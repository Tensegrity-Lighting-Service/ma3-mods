MA3 Mods 2.1.7 - USB key structure
=================================

NOTE: tested on grandMA3 onPC only (2.5.0 / 2.5.1), not yet on console hardware.

1. Copy the "grandMA3" folder of this zip to the root of a USB key
   (merge it with an existing grandMA3 folder).
2. In grandMA3: Import Plugin <n> /File "MA3Mods.xml" /nc
   (the file is in gma3_library/datapools/plugins/FDPlugins/MA3Mods on the key).
3. Call the plugin: "Update (Internet)" downloads the mods to the key (password required),
   then switch the mods On and Apply. Restart MA when asked.

Without the key, the plugin can still switch installed mods off and restore the console.
https://github.com/Tensegrity-Lighting-Service/ma3-mods
